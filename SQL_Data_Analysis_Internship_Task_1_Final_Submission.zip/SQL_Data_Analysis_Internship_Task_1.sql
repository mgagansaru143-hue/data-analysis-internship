-- SQL Data Analysis Internship – Task 1
-- Student Management Database
-- Deliverable: database/table creation, INSERT statements,
-- and analysis queries.

CREATE DATABASE IF NOT EXISTS StudentManagement;
USE StudentManagement;

-- 1. Database & table creation
CREATE TABLE IF NOT EXISTS Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(50),
    Gender CHAR(1),
    Age INT,
    Grade VARCHAR(2),
    MathScore INT,
    ScienceScore INT,
    EnglishScore INT
);

-- 2. Insert statements
INSERT INTO Students
(Name, Gender, Age, Grade, MathScore, ScienceScore, EnglishScore)
VALUES
('Aarav','M',19,'A',88,91,85),
('Diya','F',18,'B',76,84,80),
('Kiran','M',20,'A',92,89,94),
('Meera','F',19,'A',95,93,90),
('Rahul','M',18,'C',68,72,70),
('Ananya','F',20,'B',81,79,86),
('Vikram','M',19,'B',74,77,73),
('Sneha','F',18,'A',89,96,92),
('Arjun','M',21,'C',65,69,71),
('Pooja','F',19,'B',84,82,88);

-- 3. Queries

-- Display all students
SELECT * FROM Students;

-- Average Math Score
SELECT AVG(MathScore) AS AvgMath
FROM Students;

-- Average Science Score
SELECT AVG(ScienceScore) AS AvgScience
FROM Students;

-- Average English Score
SELECT AVG(EnglishScore) AS AvgEnglish
FROM Students;

-- Highest Math Score
SELECT MAX(MathScore) AS HighestMath
FROM Students;

-- Students with Math score above 80
SELECT Name, MathScore
FROM Students
WHERE MathScore > 80;

-- Count students by Grade
SELECT Grade, COUNT(*) AS StudentCount
FROM Students
GROUP BY Grade;

-- Update a student's Math score
UPDATE Students
SET MathScore = 90
WHERE Name = 'Aarav';

-- Verify the update
SELECT Name, MathScore
FROM Students
WHERE Name = 'Aarav';
